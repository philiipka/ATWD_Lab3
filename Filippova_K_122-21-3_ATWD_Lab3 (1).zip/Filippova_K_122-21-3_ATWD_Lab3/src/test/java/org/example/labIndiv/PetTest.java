package org.example.labIndiv;

import com.github.javafaker.Faker;
import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.parsing.Parser;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Map;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

public class PetTest {

    private static final String BASE_URL = "https://petstore.swagger.io/v2";
    private static final String PET = "/pet";
    private static final String PET_ID = PET + "/{petId}";

    private long petId; // Унікальний ID для тесту
    private String petName; // Ім'я тварини

    @BeforeClass
    public void setup() {
        RestAssured.baseURI = BASE_URL;
        RestAssured.defaultParser = Parser.JSON;
        RestAssured.requestSpecification = new RequestSpecBuilder()
                .setContentType(ContentType.JSON)
                .build();
        RestAssured.responseSpecification = new ResponseSpecBuilder().build();
    }

    @Test
    public void verifyCreatePet() {
        Faker faker = Faker.instance();
        petId = Long.parseLong("122213"); // Номер групи + студент
        petName = faker.animal().name();

        Map<String, ?> body = Map.of(
                "id", petId,
                "name", petName,
                "status", "available"
        );

        given()
                .body(body)
                .post(PET)
                .then()
                .statusCode(HttpStatus.SC_OK)
                .body("name", equalTo(petName))
                .body("status", equalTo("available"));
    }

    @Test(dependsOnMethods = "verifyCreatePet")
    public void verifyGetPet() {
        given()
                .pathParam("petId", petId)
                .get(PET_ID)
                .then()
                .statusCode(HttpStatus.SC_OK)
                .body("name", equalTo(petName))
                .body("id", equalTo((int) petId));
    }

    @Test(dependsOnMethods = "verifyGetPet")
    public void verifyUpdatePet() {
        String updatedStatus = "sold";

        Map<String, ?> body = Map.of(
                "id", petId,
                "name", petName,
                "status", updatedStatus
        );

        given()
                .body(body)
                .put(PET)
                .then()
                .statusCode(HttpStatus.SC_OK)
                .body("status", equalTo(updatedStatus));
    }

    @Test(dependsOnMethods = "verifyUpdatePet")
    public void verifyDeletePet() {
        given()
                .pathParam("petId", petId)
                .delete(PET_ID)
                .then()
                .statusCode(HttpStatus.SC_OK);
    }
}