package org.example.lab3;

import com.github.javafaker.Faker;
import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.parsing.Parser;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import java.util.Map;

import static org.hamcrest.Matchers.equalTo;
import static io.restassured.RestAssured.given;

public class LabTest {

    // Базова URL-адреса API Petstore.
    private static final String BASE_URL = "https://petstore.swagger.io/v2";
    private static final String USER = "/user";
    private static final String USER_USERNAME = USER + "/{username}";
    private static final String USER_LOGIN = USER + "/login";
    private static final String USER_LOGOUT = USER + "/logout";

    private String username;
    private String firstName;

    @BeforeClass
    public void setup() {
        // Налаштування базової URL-адреси та специфікацій запитів/відповідей перед запуском тестів.
        RestAssured.baseURI = BASE_URL;
        RestAssured.defaultParser = Parser.JSON;
        RestAssured.requestSpecification = new RequestSpecBuilder()
                .setContentType(ContentType.JSON)
                .build();
        RestAssured.responseSpecification = new ResponseSpecBuilder().build();
    }

    @Test
    public void verifyLoginAction() {
        Map<String, ?> body = Map.of(
                "username", "Khrystyna Filippova",
                "password", "122-21-3"
        );
        Response response = given().body(body).get(USER_LOGIN);

        response.then().statusCode(HttpStatus.SC_OK);

        RestAssured.requestSpecification
                .sessionId(response.jsonPath()
                        .get("message")
                        .toString()
                        .replaceAll("[^0-9]", ""));
    }

    @Test(dependsOnMethods = "verifyLoginAction")
    public void verifyCreateAction() {
        Faker faker = Faker.instance();
        this.username = faker.name().username();
        firstName = faker.harryPotter().character();

        Map<String, ?> body = Map.of(
                "username", username,
                "firstName", firstName,
                "lastName", faker.gameOfThrones().character(),
                "email", faker.internet().emailAddress(),
                "password", faker.internet().password(),
                "phone", faker.phoneNumber().phoneNumber(),
                "userStatus", 1 // Статус користувача.
        );
        given()
                .body(body)
                .post(USER)
                .then()
                .statusCode(HttpStatus.SC_OK);
    }

    @Test(dependsOnMethods = "verifyCreateAction")
    public void verifyGetAction() {
        given()
                .pathParam("username", this.username)
                .get(USER_USERNAME)
                .then()
                .statusCode(HttpStatus.SC_OK)
                .body("firstName", equalTo(firstName));
    }
    @Test(dependsOnMethods = "verifyGetAction")
    public void verifyDeleteAction() {
        given()
                .pathParam("username", username)
                .delete(USER_USERNAME)
                .then()
                .statusCode(HttpStatus.SC_OK);
    }
    @Test(dependsOnMethods = "verifyLoginAction")
    public void verifyLogoutAction() {
        given()
                .get(USER_LOGOUT)
                .then()
                .statusCode(HttpStatus.SC_OK);
    }

}